## Tic-Tac-Toe

### Softwares:

1. Python 3.7
2. Anaconda 3
3. Jupyter

### Libraries:

1. Matplotlib
2. Numpy
3. Pandas

### Classification Models:

1. Naive Bayes(Benchmark Model)
2. Logistic Regression
3. Decision Tree
4. Random Forest

### Metrics:

1. Accuracy
